import styles from "@/styles/BookingProposal.module.css";
import React, { useEffect, useState } from "react";
import Select from "react-select";
import { useSelector } from "react-redux";
import { createBooking } from "../api/bookings";
import { getEventsByVenueToken } from "../api/events"; // api pour récupérer les events du venue
import formatDate from '../utils/dateFormater';
import { MobileTimePicker } from '@mui/x-date-pickers/MobileTimePicker'; // Pour saisir une heure de début sur une horloge
import { getVenueByToken } from "@/api/venues";
import { getArtist } from "@/api/artists";
import { useRouter } from "next/navigation";
import ReactSelect from "react-select";
import { customStyles } from "@/styles/CustomSlect";

const CreateBookingProposal = ({ isOpen, onClose, artist, event }) => {
  const router = useRouter();
  const [hour_start, setHour_start] = useState(); // Input hour_start
  const [duration, setDuration] = useState(); // Input duration
  const [description, setDescription] = useState(""); // input desc
  const [rate, setRate] = useState(); //input rate
  const user = useSelector((state) => state.user.value);
  const [venue, setVenue] = useState(""); // Objet venue
  const [events, setEvents] = useState([]); // Liste des events
  const [eventBooking, setEventBooking] = useState(""); // event selectionné pour le booking
  const [artistBook, setArtistBook] = useState(""); // artist selectionné pour le booking
  const [loading, setLoading] = useState(false);
  const [hasEvents, setHasEvents] = useState(false);

  useEffect(() => {
    if (user.isVenue) {
      getVenueByToken(user.token).then(data => {
        setVenue(data.venue._id);
      });
      getEventsByVenueToken(user.token) // Je récupère les events de l'artiste
        .then((data) => {
          setEvents(data.events);
          setHasEvents(data.events.length > 0);
        });
    } else {
      getArtist(user.token).then(data => {
        setArtistBook(data);
      });
    }
  }, []);

  const eventsInfos = events.map(eventOne => {
    // Utilisation de la fonction formatDate pour obtenir les éléments de la date
    const { day, month, year } = formatDate(eventOne.date);
    return { label: `${eventOne.title} ${day} ${month} ${year}`, value: eventOne._id };
  });

  const handleEventChange = (selectedOptions) => {
    console.log("current selected type: ", selectedOptions.value);
    setEventBooking(selectedOptions.value);
  };

  const handleWrapper = (event) => {
    event.stopPropagation();
  };

  const handleClose = () => {
    onClose();
  };

  const handleSubmit = async () => {
    setLoading(true);
    const status = 'En attente';
    if (user.isVenue) {
      await createBooking(user.token, user.isVenue, artist._id, venue, eventBooking, hour_start, Number(duration), Number(rate), status, description);
      setLoading(false);
      setTimeout(4000);
      router.push("/Propositions");
    } else {
      const data = await createBooking(user.token, user.isVenue, artistBook._id, event.venue, event._id, hour_start, Number(duration), Number(rate), status, description);
      console.log(data);
    }
  };

  if (!isOpen) return null;

  const isVenue = user.isVenue;

  if (isVenue && !hasEvents) {
    return (
      <div className={styles.container} onClick={handleClose}>
        <div className={styles.wrapper} onClick={handleWrapper}>
          <h3>Envoyer une proposition de booking</h3>
          <p>Vous devez créer un événement auquel ajouter le booking avant de contacter l'artiste</p>
          <button onClick={() => router.push("/CreateEvent")}>Créer un événement</button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container} onClick={handleClose}>
      <div className={styles.wrapper} onClick={handleWrapper}>
        <h3>Envoyer une proposition de booking</h3>
        <div className={styles.formElem}>
          <label>
            {isVenue ? "à l'artiste" : "Pour l'événement"}<span></span>
          </label>
          <span className={styles.title}>{isVenue ? artist.name : event.title}</span>
        </div>
        {isVenue ? (
          <ReactSelect
            placeholder="Choisissez un événement"
            styles={customStyles}
            options={eventsInfos}
            onChange={handleEventChange}
            value={eventsInfos.find((option) => option.value === eventBooking)}
          />
        ) : (
          <></>
        )}
        <div className={styles.formElem}>
          <label>
            Heure de début de la prestation <span>*</span>
          </label>
          <MobileTimePicker
            onChange={(e) => setHour_start(e)}
            value={hour_start}
            minutesStep={15}
            sx={{
              input: { color: '#fff' },
              border: '1px solid #3F88C5',
              borderRadius: '16px',
              width: '300px',
            }}
          />
        </div>
        <div className={styles.formElem}>
          <label>
            Durée de la prestation (h)<span>*</span>
          </label>
          <input
            type="number"
            onChange={(e) => setDuration(e.target.value)}
            value={duration}
            className={styles.input}
            min={'1'}
          ></input>
        </div>
        <div className={styles.formElem}>
          <label>
            Description <span>*</span>
          </label>
          <input
            className={styles.input}
            type="text"
            name="description"
            placeholder="Description de la proposition..."
            onChange={(e) => setDescription(e.target.value)}
            value={description}
          />
        </div>
        <div className={styles.formElem}>
          <label>
            Tarif proposé (€) <span>*</span>
          </label>
          <input
            className={styles.input}
            type="number"
            name="rate"
            placeholder="Tarif que vous proposez pour la prestation (€)"
            onChange={(e) => setRate(e.target.value)}
            value={rate}
            step={5}
          />
        </div>
        <div id="alert"></div>
        <button
          className={styles.buttonMain}
          id="Send booking proposal"
          onClick={() => handleSubmit()}
        >
          {loading ? "Chargement..." : "Envoyer la proposition"}
        </button>
      </div>
    </div>
  );
};

export default CreateBookingProposal;
